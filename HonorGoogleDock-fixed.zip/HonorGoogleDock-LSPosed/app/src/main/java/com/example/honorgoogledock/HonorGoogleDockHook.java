package com.example.honorgoogledock;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.ViewTreeObserver;
import android.widget.Toast;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HonorGoogleDockHook implements IXposedHookLoadPackage {
    private static final String TAG = "HonorGoogleDock: ";
    private static final String[] LAUNCHER_CLASSES = {
        "com.android.launcher3.Launcher",
        "com.hihonor.android.launcher.Launcher"
    };

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.hihonor.android.launcher".equals(lpparam.packageName)
                && !"com.android.launcher3".equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + "loaded in " + lpparam.packageName + "; hooking Launcher.onResume");
        boolean hooked = false;
        for (String cls : LAUNCHER_CLASSES) {
            try {
                XposedHelpers.findAndHookMethod(cls, lpparam.classLoader, "onResume", new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        if (!(param.thisObject instanceof Activity)) return;
                        final Activity activity = (Activity) param.thisObject;
                        if (activity.isFinishing() || activity.isDestroyed()) return;
                        activity.getWindow().getDecorView().post(() -> installBar(activity));
                    }
                });
                XposedBridge.log(TAG + "hooked " + cls + ".onResume()");
                hooked = true;
            } catch (Throwable t) {
                XposedBridge.log(TAG + "class/method not available: " + cls + " (" + t.getClass().getSimpleName() + ")");
            }
        }
        if (!hooked) XposedBridge.log(TAG + "WARNING: no Launcher class hooked");
    }

    private static void installBar(Activity activity) {
        try {
            View decor = activity.getWindow().getDecorView();
            if (!(decor instanceof ViewGroup)) return;
            ViewGroup root = (ViewGroup) decor;
            View existing = decor.findViewWithTag("HonorGoogleDock.searchbar");
            if (existing != null && existing.getParent() != null) {
                // Do not leave a previously hidden bar stuck as GONE after a launcher refresh.
                existing.setVisibility(containsPageReorderTitle((ViewGroup) decor) ? View.GONE : View.VISIBLE);
                return;
            }

            Context ctx = activity;
            int h = dp(ctx, 54);
            int side = dp(ctx, 22);
            // Raise the overlay above the launcher dock icons instead of covering them.
            int bottom = dp(ctx, 112);

            LinearLayout bar = new LinearLayout(ctx);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(dp(ctx, 16), 0, dp(ctx, 14), 0);
            bar.setElevation(dp(ctx, 8));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.rgb(250, 250, 252));
            bg.setCornerRadius(dp(ctx, 28));
            bg.setStroke(dp(ctx, 1), Color.rgb(225, 227, 232));
            bar.setBackground(bg);
            bar.setContentDescription("Google search");
            bar.setTag("HonorGoogleDock.searchbar");

            TextView g = new TextView(ctx);
            g.setText("G");
            g.setTextSize(25);
            g.setTypeface(Typeface.DEFAULT_BOLD);
            g.setTextColor(Color.rgb(66, 133, 244));
            g.setGravity(Gravity.CENTER);
            bar.addView(g, new LinearLayout.LayoutParams(dp(ctx, 32), -1));

            EditText input = new EditText(ctx);
            input.setSingleLine(true);
            input.setTextSize(16);
            input.setTextColor(Color.rgb(40, 40, 40));
            input.setHintTextColor(Color.rgb(105, 108, 115));
            input.setHint("Search");
            input.setBackgroundColor(Color.TRANSPARENT);
            input.setPadding(dp(ctx, 10), 0, dp(ctx, 4), 0);
            input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
            input.setSelectAllOnFocus(false);
            LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, -1, 1f);
            bar.addView(input, inputLp);

            TextView mic = new TextView(ctx);
            mic.setText("🎙");
            mic.setTextSize(19);
            mic.setGravity(Gravity.CENTER);
            bar.addView(mic, new LinearLayout.LayoutParams(dp(ctx, 34), -1));

            View.OnClickListener launchSearch = v -> launchGoogleSearch(activity, input.getText().toString());
            g.setOnClickListener(launchSearch);
            mic.setOnClickListener(v -> {
                try {
                    Intent voice = new Intent("android.intent.action.VOICE_ASSIST");
                    voice.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(voice);
                } catch (Throwable t) { launchGoogleSearch(activity, ""); }
            });
            input.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                    ((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(input.getWindowToken(), 0);
                    launchGoogleSearch(activity, input.getText().toString());
                    return true;
                }
                return false;
            });

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, h, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            lp.leftMargin = side;
            lp.rightMargin = side;
            lp.bottomMargin = bottom;
            root.addView(bar, lp);

            // Honor Launcher keeps the same Activity while entering page-reorder / edit mode.
            // Observe the visible view tree and hide the overlay whenever edit controls are present.
            ViewTreeObserver observer = decor.getViewTreeObserver();
            observer.addOnGlobalLayoutListener(() -> {
                try {
                    boolean editMode = containsPageReorderTitle((ViewGroup) decor);
                    bar.setVisibility(editMode ? View.GONE : View.VISIBLE);
                } catch (Throwable ignored) { }
            });

            XposedBridge.log(TAG + "Google search bar added; edit-mode auto-hide enabled");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "install bar failed: " + t);
        }
    }


    // Use only the exact page-reorder title seen in the user's screenshot.
    // Broad matches such as "widgets" or "desktop settings" can exist in hidden
    // launcher views even on the normal home screen and incorrectly hide the bar.
    private static boolean containsPageReorderTitle(View view) {
        if (view == null) return false;
        if (view instanceof TextView) {
            CharSequence cs = ((TextView) view).getText();
            if (cs != null && cs.toString().trim().contains("拖动页面可改变页面顺序")) return true;
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                if (containsPageReorderTitle(group.getChildAt(i))) return true;
            }
        }
        return false;
    }

    private static void launchGoogleSearch(Activity activity, String query) {
        try {
            Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
            i.putExtra("query", query == null ? "" : query);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(i);
        } catch (Throwable first) {
            try {
                Intent i = activity.getPackageManager().getLaunchIntentForPackage("com.google.android.googlequicksearchbox");
                if (i != null) {
                    if (query != null && !query.trim().isEmpty()) i.putExtra("query", query.trim());
                    activity.startActivity(i);
                } else {
                    Intent web = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(query == null ? "" : query)));
                    activity.startActivity(web);
                }
            } catch (Throwable t) { XposedBridge.log(TAG + "launch search failed: " + t); }
        }
    }

    private static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }
}
